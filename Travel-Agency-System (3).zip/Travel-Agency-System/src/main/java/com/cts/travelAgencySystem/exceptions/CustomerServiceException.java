package com.cts.travelAgencySystem.exceptions;

public class CustomerServiceException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8916958353134414697L;
	public CustomerServiceException(String message)
	{
		super(message);
	}

	
	
	

}
