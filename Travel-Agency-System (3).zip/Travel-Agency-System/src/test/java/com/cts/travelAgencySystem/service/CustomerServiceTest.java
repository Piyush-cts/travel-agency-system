package com.cts.travelAgencySystem.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;


import com.cts.travelAgencySystem.repository.CustomerRepository;
import com.cts.travelAgencySystem.ui.model.response.Customer;
@SpringBootTest
class CustomerServiceTest {
	@Autowired
	CustomerService service;
	
	@MockBean
	CustomerRepository repository;
	
	@BeforeEach
	void setUp() {
		Optional<Customer> customer=Optional.ofNullable(new Customer(1,"piyush","verma","kanpur","ghaziabad",7,"holi",3000,"1/10 avas vikas kanpur",
				"1/10 avas vikas kanpur","9140953328","vacation"));
		Mockito.when(repository.findById(1)).thenReturn(customer);
	}
	
	
   @Test
   public void getCustomerByIdTest() {
	   String customer_name ="piyush";
	   Customer customer=service.getCustomerById(1);
	   assertEquals(customer_name, customer.getFirstName());
	   
	   
   }

}
