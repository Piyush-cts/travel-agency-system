package com.cts.travelAgencySystem;
import org.springframework.boot.test.context.SpringBootTest;




@SpringBootTest
class TravelAgencySystemApplicationTests {
	

	






}
