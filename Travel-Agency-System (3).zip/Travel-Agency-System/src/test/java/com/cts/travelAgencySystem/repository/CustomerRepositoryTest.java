package com.cts.travelAgencySystem.repository;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import com.cts.travelAgencySystem.ui.model.response.Customer;
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class CustomerRepositoryTest {
	
	@Autowired
	CustomerRepository repository;
	
	@Autowired
	private TestEntityManager entityManager;
	
	@BeforeEach
	void setUp() {
		Customer customer=new Customer(2,"piyush","verma","kanpur","ghaziabad",7,"holi",3000,"1/10 avas vikas kanpur",
				"1/10 avas vikas kanpur","9140953328","vacation");
		entityManager.persist(customer);
	}
    @Test
	public void testFindById() {
    	Customer customer= repository.findById(2).get();
    	assertEquals("piyush", customer.getFirstName());
    	
		
	}

}
