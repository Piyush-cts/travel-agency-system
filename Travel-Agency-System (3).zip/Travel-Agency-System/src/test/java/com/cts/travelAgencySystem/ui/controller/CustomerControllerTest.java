package com.cts.travelAgencySystem.ui.controller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.cts.travelAgencySystem.service.CustomerService;
import com.cts.travelAgencySystem.ui.model.request.CustomerDetails;
import com.cts.travelAgencySystem.ui.model.response.Customer;
@WebMvcTest(CustomerController.class)
class CustomerControllerTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private CustomerService service;
	
	private Customer customer;
	
	@BeforeEach
	void setUp() {
		Customer customer=new Customer(2,"piyush","verma","kanpur","ghaziabad",7,"holi",3000,"1/10 avas vikas kanpur",
				"1/10 avas vikas kanpur","9140953328","vacation");
		CustomerDetails customerDetails=new CustomerDetails(2,"piyush","verma","kanpur","ghaziabad",7,"holi",3000,"1/10 avas vikas kanpur",
				"1/10 avas vikas kanpur","9140953328","vacation");
		Mockito.when(service.createCustomer(customerDetails)).thenReturn(customer);
	}

	@Test
	public void testAddCustomer() throws Exception {
		
		Customer customer=new Customer(2,"piyush","verma","kanpur","ghaziabad",7,"holi",3000,"1/10 avas vikas kanpur",
				"1/10 avas vikas kanpur","9140953328","vacation");
		CustomerDetails customerDetails=new CustomerDetails(2,"piyush","verma","kanpur","ghaziabad",7,"holi",3000,"1/10 avas vikas kanpur",
				"1/10 avas vikas kanpur","9140953328","vacation");
		Mockito.when(service.createCustomer(customerDetails)).thenReturn(customer);
		
		mockMvc.perform(MockMvcRequestBuilders.post("http://localhost:8080/TravelAgency/save").
				accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON).
				content("{\r\n" + 
						"  \"id\": 2,\r\n" + 
						"  \"firstName\": \"piyush\",\r\n" + 
						"  \"lastName\": \"verma\",\r\n" + 
						"  \"startingLocation\": \"kanpur\"\r\n" + 
						"  \"destinationLocation\": \"ghaziabad\"\r\n" +
						"  \"locations\": 7,\r\n" + 
						"  \"packageName\": \"holi\"\r\n" +
						"  \"cost\": 3000,\r\n" + 
						"  \"permanentAddress\": \"1/10 avas vikas kanpur\"\r\n" +
						"  \"communicationAddress\": \"1/10 avas vikas kanpur\"\r\n" +
						"  \"phone\": \"9140953328\"\r\n" +
						"  \"notes\": \"vacation\"\r\n" +"}")).andExpect(MockMvcResultMatchers.status().isOk());
								
		
	}

}
