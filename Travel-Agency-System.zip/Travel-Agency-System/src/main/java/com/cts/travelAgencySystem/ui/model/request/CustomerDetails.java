package com.cts.travelAgencySystem.ui.model.request;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class CustomerDetails {
	
	 @NotNull(message = "first name can not be null")
	 @Size(min=2,message = "first name can not be less then 2")
	private String firstName;
	 @NotNull(message = "last name can not be null")
	  @Size(min=2,message = "last name can not be less then 2")
	private String lastName;
	 @NotNull(message = "starting location can not be null")
	private String startingLocation;
	 @NotNull(message = "destination location can not be null")
	private String destinationLocation;
	 @NotNull(message = "locations can not be null")
	private int locations;
	 @NotNull(message = "package name can not be null")
	private String packageName;
	 @NotNull(message = "cost can not be null")
	private int cost;
	 @NotNull(message = "permanent address can not be null")
	 @Size(max=250,message = "permanent address length should  not be greater then 250")
	private String permanentAddress;
	 @NotNull(message = "communication address can not be null")
	 @Size(max=250,message = "communication address length should  not be greater then 250")
	private String communicationAddress;
	 @NotNull(message = "phone can not be null")
	 @Size(min=0,max=10)
	 @Pattern(regexp="(^$|[0-9]{10})")
	private String phone;
	 @Size(max=250,message = "notes length should  not be greater then 250")
	 @NotNull(message = "notes can not be null")
	private String notes;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getStartingLocation() {
		return startingLocation;
	}
	public void setStartingLocation(String startingLocation) {
		this.startingLocation = startingLocation;
	}
	public String getDestinationLocation() {
		return destinationLocation;
	}
	public void setDestinationLocation(String destinationLocation) {
		this.destinationLocation = destinationLocation;
	}
	public int getLocations() {
		return locations;
	}
	public void setLocations(int locations) {
		this.locations = locations;
	}
	public String getPackageName() {
		return packageName;
	}
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public String getPermanentAddress() {
		return permanentAddress;
	}
	public void setPermanentAddress(String permanentAddress) {
		this.permanentAddress = permanentAddress;
	}
	public String getCommunicationAddress() {
		return communicationAddress;
	}
	public void setCommunicationAddress(String communicationAddress) {
		this.communicationAddress = communicationAddress;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public CustomerDetails(@NotNull(message = "first name can not be null") String firstName,
			@NotNull(message = "last name can not be null") String lastName,
			@NotNull(message = "starting location can not be null") String startingLocation,
			@NotNull(message = "destination location can not be null") String destinationLocation,
			@NotNull(message = "locations can not be null") int locations,
			@NotNull(message = "package name can not be null") String packageName,
			@NotNull(message = "cost can not be null") int cost,
			@NotNull(message = "permanent address can not be null") @Size(max = 250, message = "permanent address length should  not be greater then 250") String permanentAddress,
			@NotNull(message = "communication address can not be null") @Size(max = 250, message = "communication address length should  not be greater then 250") String communicationAddress,
			@NotNull(message = "phone can not be null") @Size(min = 0, max = 10) @Pattern(regexp = "(^$|[0-9]{10})") String phone,
			@Size(max = 250, message = "notes length should  not be greater then 250") @NotNull(message = "notes can not be null") String notes) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.startingLocation = startingLocation;
		this.destinationLocation = destinationLocation;
		this.locations = locations;
		this.packageName = packageName;
		this.cost = cost;
		this.permanentAddress = permanentAddress;
		this.communicationAddress = communicationAddress;
		this.phone = phone;
		this.notes = notes;
	}
	
	
	
	

}
