package com.cts.travelAgencySystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.travelAgencySystem.repository.CustomerRepository;
import com.cts.travelAgencySystem.ui.model.request.CustomerDetails;
import com.cts.travelAgencySystem.ui.model.request.UpdateCustomerDetails;
import com.cts.travelAgencySystem.ui.model.response.Customer;

@Service
public class CustomerService {
	@Autowired
	CustomerRepository customerRepository;
	
	public Customer createCustomer(CustomerDetails customerDetails)
	{
		Customer customer=new Customer();
		customer.setFirstName(customerDetails.getFirstName());
		customer.setLastName(customerDetails.getLastName());
		customer.setStartingLocation(customerDetails.getStartingLocation());
		customer.setDestinationLocation(customerDetails.getDestinationLocation());
		customer.setLocations(customerDetails.getLocations());
		customer.setPackageName(customerDetails.getPackageName());
		customer.setCost(customerDetails.getCost());
		customer.setPermanentAddress(customerDetails.getPermanentAddress());
		customer.setCommunicationAddress(customerDetails.getCommunicationAddress());
		customer.setPhone(customerDetails.getPhone());
		customer.setNotes(customerDetails.getNotes());
		customerRepository.save(customer);
		return customer;
		
	}
	
	public Customer getCustomerById(int id)
	{
		return customerRepository.findById(id).get();
	}
	
	public Customer updateCustomer(int id,UpdateCustomerDetails updateCustomerDetails)
	{
		Customer customer=getCustomerById(id);
		if(customer!=null)
		{
			customer.setFirstName(updateCustomerDetails.getFirstName());
			customer.setLastName(updateCustomerDetails.getLastName());
			customer.setStartingLocation(updateCustomerDetails.getStartingLocation());
			customer.setDestinationLocation(updateCustomerDetails.getDestinationLocation());
			customer.setLocations(updateCustomerDetails.getLocations());
			customer.setPackageName(updateCustomerDetails.getPackageName());
			customer.setCost(updateCustomerDetails.getCost());
			customer.setPermanentAddress(updateCustomerDetails.getPermanentAddress());
			customer.setCommunicationAddress(updateCustomerDetails.getCommunicationAddress());
			customer.setPhone(updateCustomerDetails.getPhone());
			customer.setNotes(updateCustomerDetails.getNotes());
			customerRepository.save(customer);
			
		}
		return customer;
		
	}
	
	public void deleteCustomer(int id)
	{
		Customer customer=getCustomerById(id);
		customerRepository.delete(customer);
		
	}

}
