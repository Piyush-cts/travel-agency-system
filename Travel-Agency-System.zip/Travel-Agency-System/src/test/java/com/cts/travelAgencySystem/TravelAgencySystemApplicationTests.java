package com.cts.travelAgencySystem;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cts.travelAgencySystem.repository.CustomerRepository;
import com.cts.travelAgencySystem.ui.model.response.Customer;

@SpringBootTest
class TravelAgencySystemApplicationTests {
	
	@Autowired
	CustomerRepository repository;
	@org.junit.jupiter.api.Test
	public void saveCustomerTest() {
		
	Customer customer=new Customer("abc","xyz","kanpur","ghaziabad",7,"holi",3000,
				"1/10 avas vikas kanpur","1/10 avas vikas kanpur","9140953328","vacation");
	repository.save(customer);
	assertEquals(18, customer.getId());
		
		
	}




}
